planets Venus and Jupiter further increase his warm personality and magnetism. It's not so much what he does but who he is that wins people's hearts. Like the Sun, such individuals cannot pass unnoticed.

Appearance: Sun in the first house gives a large, strong, tall and well-proportioned body; a round and large forehead, large, piercing eyes. It gives good health, ruddy complexion, often blond hair and the tendency of hair loss in later years.

A native tends to quickly recover from illnesses and accidents, even when his Sun isn't well aspected. It's likely that the native will pay a lot of attention to the body, and therefore the body will serve him well even in old age.

With such a placement a native is likely to look similar to his or her father; the father is likely to be a role-model.

Here are some celebrities with Sun in the first house:
![img-0.jpeg](img-0.jpeg)

A prominent and afflicted Sun can make a person domineering, arrogant, proud, and a hater of all people. His judgement will be wrong, he will be restless and troublesome.

He could become a spendrift and may become financially dependent on other people; but he will think others to owe him for the kind of person that he is. He is also likely to crave for admiration and then get unhappy that he doesn't receive it, not understanding that admiration has to be earned.